#!/bin/bash

## installing java
java -version
wget --no-cookies --no-check-certificate --header "Cookie: gpw_e24=http%3A%2F%2Fwww.oracle.com%2F; oraclelicense=accept-securebackup-cookie" "http://download.oracle.com/otn-pub/java/jdk/8u66-b17/jdk-8u66-linux-x64.tar.gz"
tar -zxvf jdk-8u66-linux-x64.tar.gz


## tomcat installation

wget http://mirror.cc.columbia.edu/pub/software/apache/tomcat/tomcat-7/v7.0.73/bin/apache-tomcat-7.0.73.tar.gz
mkdir /usr/share/tomcat
mv apache-tomcat-7.0.73.tar.gz /usr/share/tomcat
tar -xvzf apache-tomcat-7.0.73.tar.gz

apt-get install mysql-server
